class Heart {
    constructor(img, x, y, room) {
        this.img = img
        this.pos = createVector(x, y)
        this.width = 16 * 5; //80
        this.height = 16 * 5;
        // this.width = 32;
        // this.height = 32;
        this.room = room;
        this.hitbox = {
            xdiff: 20,
            ydiff: 10,
            w: 45,
            h: 60
        }
    }

    display() {
        // noStroke()
        // fill(255, 255, 0, 100)
        // rect(this.pos.x + this.hitbox.xdiff, this.pos.y + this.hitbox.ydiff, this.hitbox.w, this.hitbox.h)
        // fill(180, 50, 50, 100);
        // rect(this.pos.x, this.pos.y, this.width, this.height)
        image(this.img, this.pos.x, this.pos.y)
    }
}