class Player {
  constructor() {
    // this.width = 64;
    // this.height = 64;
    this.img;
    this.player = {}
    this.width = 32 * 6;
    this.height = 32 * 6
    this.pos = createVector(0, 640 - this.height);
    this.velocity = createVector(0, 0);
    this.gravity = 2;
    this.sides = {
      bottom: this.pos.y + this.height,
    };
    this.hitbox = {
      xdiff: 54,
      ydiff: 35,
      w: 16 * 6,
      h: 26 * 6
    }
    this.isIdleLeft = false;
    this.isIdleRight = true;
  }

  load(obj) {
    this.player = obj;
  }

  display() {
    // //displays box on player
    // noStroke()
    // fill(255, 255, 0, 100)
    // rect(this.pos.x + this.hitbox.xdiff, this.pos.y + this.hitbox.ydiff, this.hitbox.w, this.hitbox.h)

    // //displays box around player
    // fill(255, 20, 255, 100)
    // rect(this.pos.x, this.pos.y, this.width, this.height)

    if(keys.a.pressed == true){
      this.img = this.player.runLeft
    }
    else if(keys.d.pressed == true){
      this.img = this.player.runRight
    }
    else if(this.isIdleLeft == true){
      this.img = this.player.idleLeft
    }
    else{
      this.img = this.player.idleRight;

    }

    image(this.img, this.pos.x, this.pos.y)
  }

  update() {
    this.hitbox = {
      x: this.pos.x + 61,
      y: this.pos.y + 40,
      w: 16 * 7,
      h: 26 * 7
    }
  }


}
