class Room {
    constructor(x, y, img) {
        this.img = img
        this.pos = createVector(x, y)
        this.overlays = [];
        this.leftWalls = [];
        this.rightWalls = []
        this.obstacles = [];
        this.doors = [];
    }
    addOverlay(overlay) {
        this.overlays.push(overlay);
    }

    display() {
        image(this.img, this.pos.x, this.pos.y, 1920, 822)
        
        if (this.overlays.length > 0) {
            for (let i = 0; i < this.overlays.length; i++) {
              image(this.overlays[i], 0, 0);
            }
        }
    }

    displayBlocks() {
        if (this.leftWalls.length != 0) {
            this.leftWalls.forEach((block) => {
                block.display();
            });
        }

        if (this.rightWalls.length != 0) {
            this.rightWalls.forEach((block) => {
                block.display();
            });
        }

        if (this.obstacles.length != 0) {
            this.obstacles.forEach((block) => {
                block.display();
            });
        }
    }

    addObstacles(arr) {
        this.obstacles = arr;
    }

    addDoors(arr) {
        this.doors = arr;
    }

    addWalls(left, right) {
        this.leftWalls = left;
        this.rightWalls = right;
    }
}