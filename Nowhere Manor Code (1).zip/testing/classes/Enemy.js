class Enemy {
    constructor(x, y, room) {
        this.img;
        this.width = 32 * 8;
        this.height = 32 * 8;
        this.pos = createVector(x, y)
        this.room = room;
        this.dir = 1;
        this.step = 3;
        this.enemy = {}
        this.hitbox = {};
    }

    load(obj) {
        this.enemy = obj;
    }

    display() {
        // fill(100, 0, 200, 100);
        // rect(this.pos.x, this.pos.y, this.width, this.height);

        if (this.dir < 0 && this.step != 0) {
            if(this.step > 4){
                //run left
                this.img = this.enemy.runLeft;
            }
            else{
                this.img = this.enemy.moveLeft
            }
        }
        else if (this.dir > 0 && this.step != 0) {
            if(this.step > 4){
                //run right
                this.img = this.enemy.runRight;
            }
            else{
                this.img = this.enemy.moveRight
            }
        }
        else if (step != 0 && dir < 0) {
            if(this.step > 4){
                //run right
                this.img = this.enemy.runLeft;
            }
            else{
                this.img = this.enemy.moveLeft
            }
        }
        else if(step == 0 && dir < 0){
            this.img = this.enemy.idleLeft;
        }
        else{
            this.img = this.enemy.idleRight;
        }

        image(this.img, this.pos.x, this.pos.y)
    }

    update() {
        //increase/decease speed of enemy
        if (second() % 4 == 0) {
            this.step = random(2,4);
            this.img = this.enemy.idleRight;
        }
        else if(second() % 2 == 0) {
            this.step = random(5,10)
        }
        else {
            this.step = 0;
        }

        //update position
        this.pos.x += this.step * this.dir;

        //turn away from walls
        if(this.pos.x <= 0 || this.pos.x >= width ){
            this.dir = this.dir * -1;
          }

    }
}