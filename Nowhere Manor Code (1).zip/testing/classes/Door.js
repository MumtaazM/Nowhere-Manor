class Door {
    constructor(x,y, w, h,room){
      this.pos = createVector(x,y)
      this.width = w;
      this.height = h;
      this.sides = {
        top: y,
        bottom : y + h,
        left: x,
        right: x + width
      }
      this.openTo = room;
    }
  }