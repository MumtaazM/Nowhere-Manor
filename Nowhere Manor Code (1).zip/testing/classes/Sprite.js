class Sprite {
    constructor(x,y, imgsrc){
      this.src = imgsrc;
      this.pos = createVector(x,y)
      this.img = loadImage(this.src);
    }
    
    display(){
      image(this.img, this.pos.x, this.pos.y)
    }
  }