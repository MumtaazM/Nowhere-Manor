class CollisionBlock {
    constructor(x,y, col){
      this.pos = {x: x, y: y};
      this.width = 32;
      this.height = 32;
      
      if(col == 'red'){
        this.col = 'rgba(255, 0, 0, 0.5)'
      }
      if(col == 'green'){
        this.col = 'rgba(0, 255, 0, 0.5)'
      }
      if(col == 'blue'){
        this.col = 'rgba(0, 0, 255, 0.5)'
      }
    }
    
    display(){
      
      push()
      ctx.fillStyle = this.col;
      ctx.fillRect(this.pos.x, this.pos.y, this.width, this.height)
      pop()
    }
  }